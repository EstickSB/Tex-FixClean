export const SortType = {
  NONE: 'none',
  ALPHABETICAL: 'alphabetical',
  ASCII: 'ascii',
  REVERSE: 'reverse'
};